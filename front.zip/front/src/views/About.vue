<template>
  <div class="about">
    <h1> Technologies Used Are: </h1> <br>
    <h2> VueJS </h2> <br>
    <h2> Vuetify </h2> <br>
    <h2> Firebase </h2> <br>
    <h2> Firestore </h2> <br>
    <br> <br> <br> <br>
    <h3>" This Project was one of the many ideas that we thought about during Hack36 "</h3> <br>
    <h4 style="margin-left: 600px;">- Kshitiz Jain</h4>
  </div>
</template>
